import java.util.Scanner;

public class Ex2 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String str;
        System.out.println("한영 단어 검색 프로그램입니다.");
        while (true) {
            System.out.print("한글단어?");
            str = sc.nextLine();        // sc.next();
            if (str.equals("그만")) { sc.close(); break; }
            System.out.println(str + Dictionary.kor2Eng(str));
        }
    }
}
