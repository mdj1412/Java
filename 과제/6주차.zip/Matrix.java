public class Matrix {
    public void printMatrix(int[][] matrix) {
        for (int[] e : matrix) {
            for (int n : e) { System.out.print(n + " "); }
            System.out.println();
        }
        System.out.println();
    }
    
    public void addMatrix(int[][] arr1, int[][] arr2, int[][] arr3) {
        for (int i=0;i<arr3.length;i++)
            for (int j=0;j<arr3[i].length;j++)
                arr3[i][j] += arr1[i][j] + arr2[i][j];
    }
}
