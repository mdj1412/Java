import java.util.Scanner;

public class MonthSchedule {
    private Scanner sc = new Scanner(System.in);
    private int date;
    private Day[] month;

    public MonthSchedule(int num) {
        date = num;
        month = new Day[date];
        for (int i=0;i<date;i++) { month[i] = new Day(); }
    }
    public void input() {
        System.out.print("날짜(1~" + date + ")?");
        int day = sc.nextInt();
        if ((day<1)||(day>date)) {
            System.out.println("날짜 잘못 입력하였습니다.!");
            return;
        }
        else if (month[--day].get() == null) {                                   // 안에 저장되어 있는지 확인
            System.out.print("할일(빈칸없이입력)?");
            month[day].set(sc.next());
        }
        else { System.out.println("할 일이 이미 있습니다."); }
    }
    public void view() {
        System.out.print("날짜(1~" + date + ")?");
        int day = sc.nextInt();
        if ((day<1)||(day>date)) { System.out.println("날짜 잘못 입력하였습니다.!"); }
        else month[--day].show();
    }
    public void finish() { System.out.println("프로그램을 종료합니다."); }
}
