import java.util.Scanner;

public class Ex3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); 
        MonthSchedule ms = new MonthSchedule(30);
        System.out.println("*** 이번달 스케쥴 관리 프로그램 ***"); 
        while (true) {
            System.out.print("할일(입력:1, 보기:2, 끝내기:3) >>"); 
            int menu = scanner.nextInt();
            switch (menu) {
            case 1: ms.input(); break;
            case 2: ms.view(); break;
            case 3: ms.finish(); scanner.close(); return;
            default: System.out.println("잘못입력하였습니다."); 
            }
            System.out.println();
        }
    }
}