class Ex01{
    public static void main(String[] args){
        System.out.println("안녕하세요!");
        System.out.print("저는 ");
        System.out.println("홍길동입니다.");
        System.out.println();
        System.out.println("반갑습니다.");
    }
}
