class Ex07{
    public static void main(String[] args){
        int num=3;
        num=(num<<4)-num;                               // bit shift operator
        System.out.println("result : " + num);
    }
}
