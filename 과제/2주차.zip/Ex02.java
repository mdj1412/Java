class Ex02{
    public static void main(String[] args){
        System.out.println("안녕하세요!\n저는 홍길동입니다.\n\n반갑습니다.");
    }
}
