public class Ex05 {
    public static void main(String args[]){
        Calc c = new Calc();                        // 참조변수 c 선언 후 인스턴스 생성
        c.setValue(2, 5, '+'); 
        c.result(); 
        c.setValue(2, 5, '$'); 
        c.result(); 
        c.setValue(2, 5, '-'); 
        c.result(); 
        c.setValue(2, 5, '*'); 
        c.result(); 
        c.setValue(2, 5, '/'); 
        c.result();
    }
}
