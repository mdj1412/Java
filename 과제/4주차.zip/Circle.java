public class Circle {
    private String name;
    private double radius;
    private final double PI = 3.14;                                 // literal constant
    
    public Circle(String n, double r){
        name=n;
        setRad(r);
    }
    public void setRad(double rad){ radius = (rad>0)? rad : 0; }
    public String getName(){ return name; }
    public double getArea(){ return radius * radius * PI; }
    public void show(){
        System.out.println(getName() + "넓이 : " + getArea());
    }
}
