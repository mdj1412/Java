public class Ex02 {
    public static void main(String[] args){
        Song song = new Song("Dancing Queen", "ABBA", 1978, "스웨덴");                      // 참조변수 song 선언 후 인스턴스 생성
        song.show();
    }
}
