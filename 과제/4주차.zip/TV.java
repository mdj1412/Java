public class TV {
    private String company;
    private int year;
    private int inch;

    public TV(String x, int y, int z){
        company = x;
        year = y;
        inch = z;
    }
    public void show(){
        System.out.println(company + "에서 만든 " + year + "년형 " + inch + "인치 TV");
    }
}
